IPS EXE-Patcher v1.5 (Win32)

Disclaimer
----------

I'm am not responsible for any damage this program may cause to your 
computer. Use at your own risk!

Introduction
------------

This program creates an exe patch from IPS files. This version is Win32 
only. To use DOS version, please download IPSEXE v1.1

What's New
----------

v1.5
* 255 Character Description
* Recoded the EXE stub with ASM and avoided C library linkage!
* No more static/dynamic versions!
* Stub size is now 4kb and requires no special DLL!
* CRC testing added.
* Creates patches by file comparison.
* Open Source

v1.1

* 30 character filename support (Win32)
* GUI Implemented
* Minor bug fixes

v1.00 SR-1

* Included Win32 (static) version.

v1.00

* Code rewritten with 16-bit code instead of 32-bit.
  The problem with using 32-bits code was that I had to link it with
  WDOSX which made the exe 12.8 kb in size. The new version is linked
  with TLINK and is now 1.56 kb in size.
* A Win32 version is available for all those who thinks DOS sucks...
  However, the Win32 version seems to not work on all computers, which
  is one reason why DOS is better than Windows. :)
* Win32 version is 4.22 kb in size after compressed with UPX.

v0.99

* The first version of IPSEXE

Running the program
-------------------

Double click on ips2exe.exe to start the program.

While in the program
--------------------

Enter your copyright info, patch description, whatever... in the 
description field. You may create the EXE patch in 2 ways.

1) By comparing an unchanged file with a changed one.
2) By converting an existing patch to EXE format.

Click on the radio button to choose which way you'll use.

Way 1: Comparing an unchanged file with a changed one
-----------------------------------------------------
Select the unchanged file and the changed file. Check whether you want 
to save the patch as an EXE or an IPS. Then click "Next". You'll be 
prompted to Save As.

Way 2: Converting an existing patch to EXE format
-------------------------------------------------
Select the patch file that you will convert. Type in the filename (or 
select it) of the file that will be patched. Click "Next".

CRC Check
---------
There is a check box labeled "Enable CRC check". When creating EXE 
patches and you check this box, the program will compute a CRC value for 
the file you are going to patch and saves it. When patching the rom with 
the EXE, the program will scan the target file to check whether the file 
being patch is the same as the file originally meant to being patched. 
This is just extra error checking to make sure users don't randomly 
patch any file on their computer. This also makes sure that users patch 
the exact same file you have on your computer.

Don't use RLE
-------------
This check box specifies that when IPSEXE generates it's patch, no RLE
encoding will be used. This can be used to generate patches for programs
that do not have support for RLE encoded IPS files. Default: Off

The EXE patch
-------------
When the EXE patch is generated... it can be run by just double clicking 
it. The user can then select the file to patch by clicking browse. If 
you include a "readme.txt" along with your EXE patch, clicking the 
"Info" button will automatically launch it.
