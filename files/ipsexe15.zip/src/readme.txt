IPS EXE-Patcher v1.5 (Win32) Source

Disclaimer
----------
I'm am not responsible for any damage this code may cause to your 
computer. Use at your own risk!

Software Requirements
---------------------
* NASM v0.97
* ALINK v1.6
* GORC v0.53
* win32n.inc
* A Win32 C compiler
* GNU Make v3.77
* UPX v1.01 (Optional)

To Compile
----------
1)
Place win32n.inc inside the src directory.
2)
Run 'make' to build ipsexew.exe which is the stub of the program.
Rename this to 'ipsexe.stb'. You can compress the stub with UPX if
you want to.
3)
Using NASM, assemble crc32.asm and ZeroMem.asm to object files.
4)
Using a Win32 C Compiler, compile ips.c into a DLL.
5)
Using a Win32 C Compiler, compile the source ips2exe.cpp, and link with
crc32.obj and ZeroMem.obj that were generated from the previous step.
Also, compile ips2exe.rc and link the import library from the DLL.