___________________________________________________________________
 Beyond Oasis
 vers�o 1.4 - por Fserve <fserve@brasnet.org>
                  Groxo_ <groxo_@hotmail.com>
 ��: Tradu-Roms - www.traduroms.cjb.net
___________________________________________________________________
 >> �ndice
___________________________________________________________________
 1. sobre a tradu��o
 2. bugs conhecidos
 3. agradecimentos 
 4. mais... (o que h� de novo)
 5. contatos
___________________________________________________________________
 >> 1. sobre a tradu��o
___________________________________________________________________
 Esse jogo, � um RPG, a tradu��o est� completa, s� est� faltando os
 acentos, que n�o foram colocados pela dificuldade de se mexer nos
 tiles deste jogo.
 Qualquer erro me contate
___________________________________________________________________
 >> 2. bugs conhecidos
___________________________________________________________________
 N�o existe um bug conhecido, mas claro, pode haver, principalmente
 erros em que a fala n�o ficou no tamanho certo.
___________________________________________________________________
 >> 3. agradecimentos
___________________________________________________________________
 Essa tradu��o vai de cora��o para uma pessoa muito querida, apesar
 de que dificilmente ela veja este trabalho.
 Muito obrigado, visitantes da Tradu-Roms e todas as pessoas que
 passam horas traduzindo e jogando jogos traduzidos.
___________________________________________________________________
 >> 4. mais
___________________________________________________________________
 Jogo: Beyond Oasis
 Data do inicio da tradu��o: 02/03/2k2
 Data do t�rmino da tradu��o: 03/03/2k2
 Data da ultima atualiza��o: 11/06/2k4
 Sistema: MEGA DRIVE / GENESIS
 Traduzido por: Fserve & Groxo_
 Conclu�do: 100%
 Caso queira aprender a traduzir, entre em
 http://www.traduroms.cjb.net v� em 'Tutorial' e leia alguns
 tutoriais, se n�o entender ou ainda tiver duvidadas, entre no chat
 da home page, e pergunte de algu�m que estiver por l�, ou ... fale
 comigo no ICQ !
 * patch 1.4 resolvidos apenas erros gramaticais, todos foram
 vistos pelos olhos do "gamer_boy". total de seis corre��es.
 * patch 1.3 novamente foram corrigidos erros nas falas, algumas
 n�o se encaixavam e etc, foram apenas mudan�as pequenas mas agora
 a tradu��o est� mais pr�xima da perfei��o :)
 * patch 1.2 corrigido muitos erros na tradu��o, dessa vez eu
 joguei o jogo por um pouco mais de tempo e constatei a exist�ncia
 de alguns erros, principalmente em falas que o texto ultrapassava
 o tamanho da caixa de di�logo, Tamb�m traduzi uns tiles.
 * patch 1.1 corrigido erros gramaticais, thanks to {ShadowJake}
___________________________________________________________________
 >> 5. contatos
___________________________________________________________________
 Contatos :
 >e-mail: 
 Fserve <fserve@brasnet.org>
 Groxo_ <groxo_@hotmail.com>
 >ICQ
 Fserve : 42269897
 >No irc : irc.brasnet.org Canal: #Tradu-Roms
 Home Pages:
 http://www.traduroms.cjb.net    [Tudo sobre o grupo de Tradu��o]
___________________________________________________________________
 visite a Tradu-Roms: www.traduroms.cjb.net
 (c) 2004 - G�rson Barreiros da Silva (Fserve)
 Manaus / AM - Brasil
___________________________________________________________________