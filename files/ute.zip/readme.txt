===============-----------------------------===============
                                 ____    ____
                    |        |       |       |
                    |        |       |       |__
                    l        l       |       |
                     \___/ .      | .     |___ . 

                   Ultimate Tile Editor
                     coded by _Faster
                   _faster@brasnet.org 


===============-----------------------------===============


------ Introdu��o ------

O Projeto U.T.E. tem como objetivo se tornar um bom editor de
tiles que suporte v�rios formatos gr�ficos e tenha como principal
capacidade facilitar a modifica��o de gr�ficos de roms para fins
n�o ilegais.

Desde o in�cio desde projeto ( que come�ou por acaso ), eu ja fiz
3 cores, o 1� era usado na vers�o n�o p�blica do U.T.E ( quando
ele era quase in�til ), o segundo foi utilizado na vers�o 0.8* 
e o terceiro foi reescrito para poder facilitar a adi��o de mais
formatos gr�ficos.

------ Caracter�sticas do Ultimate Tile Editor -------

  - Uma Interface "amig�vel"

  - Suporte total a v�rios tipos de formatos gr�ficos entre eles:
     - 1 bpp ( Atari 2600 e outros )
     - Nintendo ( Nintendo Entertainment System )
     - Game Boy ( Game Boy e Game Boy Color )
     - Master System ( Sega Master System, Sega Game Gear )
     - Super Nintendo ( Super Nintendo, Turbo Grafix 16 )

  - Efeitos para serem aplicados nos tiles:
     - Limpar
     - Inverter X ( Horizontalmente )
     - Inverter Y ( Verticalmente )
     - Girar 90�
     - Girar -90�
  - Clipboard com suporte a carregar e salvar bitmaps
  - Algumas caracteristicas do Tile Layer ;D
  - Paleta que pode ser modificada em runtime, salva e carregada
     atrav�z de arquivos

------ Hist�rico ------

Arquivo historico.txt


------ Ajuda ------

Arquivo help.txt


------ UTE Home Page -----

UTE Home Page - http://luna.spaceports.com/~cncbr/ute
Email - _faster@brasnet.org
Irc - #prog / servidor Brasnet

------ Cr�ditos ------

Programador: 
_Faster - _faster@brasnet.org 

Agradecimentos:

Skewer e alvs- Por ajudar com v�rios formatos gr�ficos.

RodrigoX_Shin - Por Traduzir a a hp para ingl�s
(http://rmxtng.cjb.net)

O Pessoal do canal #prog da Brasnet ( em especial skewer, alvs,
kobe, QB e outros que n�o me lembro agora )

Fuck You:
Nintendo - Por acabar com o NES :(
Microsoft - Pelo resto :P

------ Leia Isto antes de utilizar  o UTE -------

O AUTOR E OU BETA-TESTERS E COLABORADORES EM GERAL 
N�O TEM NENHUMA RESPONSABILIDADE POR QUALQUER DANO 
E OU PREJU�ZO CAUSADO AO USU�RIO DESTE APLICATIVO,
CORRA SEUS PR�PRIOS RISCOS.
