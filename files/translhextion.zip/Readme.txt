Whats New in 1.6?
  
- Added the ability to do search for a hex string as an alternative to text using the standard "Find" command
- Added the option to reset the change color of changed bytes to the default byte color upon saving the file


	+ This option is now the default though you can change it as desired

- Added 2-byte functionality to the ' ^ ' table extension which you can use to highlight specific bytes in a user-selectable highlight color

	+ Syntax is as follows: ^xx
	+ Alternatively, for 2-byte values the syntax is: ^xxxx

- Added the option to view hex offsets in SNES HiROM and LoROM formats


	+ When in a SNES hex mode, all hex inputs will be interpreted in that format

		~ This includes boomarks and script dump marks added manually or by tables

- Removed the need to "activate" Thingy Tables, now they are active when they are loaded
- Now the ascii for DTE values is displayed in a different, user-selectable color so they are easy to see
- Improved the speed of loading a file
- Changed Automatic Bytes Per Line setting to be turned off when first entering Thingy View
- Changed "Color Settings" dialog to accommodate new colors
- Fixed the window resizing crashing bug
- Fixed a problem with partial open that incorrectly displayed the number of changed bytes when saving
- Fixed the problem where highlighting didn't get removed when a new table was loaded
- A number of aesthetic changes have been made
- The documentation has been updated to reflect new changes