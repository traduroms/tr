Aqui est�o os erros que eu (fserve) achei no jogo at� o momento: (TEMPLO DA �GUA)
1 - Espa�o depois de "Sheikah", numa fala do jogo.
2 - "Meu pr�prios" Erro de concord�ncia verbal, fala do filho do carpiteiro.
3 - "A50 Rupees" Faltou um espa�o depois do "A", fala do vendedor de feij�es.
4 - "Feijoes M�gicos1" numero 1 em lugar indevido, fala do vendedor de feij�es.
5 - Ultrapassou a caixa de dialogo., uma fala de um Goron, que estava preso, no Temple of Fire.
6 - Quando Link est� conversando com Zelda ela diz "Eu me deixei levar por essa est�ria(...)" o correto � "Eu me deixei levar por essa hist�ria(...)"
7 - Na parte em que voc� canta am�sica de Saria para o rei Goron e ele come�a a dan�ar ele exclama "Vamos! Vamos!      Vamos!".
8 - Na vila Kakariko, quando voc� mata um dos fantasmas (?) ele diz "BAAAAAH! VOC� MEMATOU...Incr�vel!" � para ter um espa�o entre "ME MATOU".
9 - No mesmo local, quando voc� mata o outro fantasma ele diz "Sou um dos irm�o compositores da Vila Kakariko" o correto � "Sou um dos irm�os compositores(...).

(Obrigado a Raphael Toledo pela ajuda na corre��o do Zelda64 OOT BR.)


Zelda IPS 1.5 (Hyllian) -> IPS DO HYLLIAN, � este o que eu estou utilizando para
revisar o jogo.
Zelda IPS 1.6 (FSERVE) -> Meu primeiro patch corretor de erros.
Zelda 1.7 -> Segunda vers�o, demorou 4 anos, mas chegou.

README ORIGINAL:

SE ENCONTRAR ALGUM PROBLEMA NO JOGO CONTATE-ME, EXCETO SE O PROBLEMA FOR:

N�O CONSIGO EMULAR O JOGO.
R. Use o emulador Project 64 1.6, ou 1964, os dois est�o disponiveis no site "ZOPHAR"
http://www.zophar.net E VEJA SE SEU COMPUTADOR TEM OS REQUISITOS MINIMOS PARA EMULA��O
DO JOGO. (AMD DURON 600MHZ PLACA DE VIDEO 3D 16MB)

N�O CONSIGO VER O LINK QUANDO ABRO O MENU DO JOGO.
R. Isso � BUG do Emulador.

QUANDO ABRO O MENU DO JOGO, DEMORA CINCO SEGUNDOS PARA ELE ABRIR.
R. Isso � BUG do Emulador, e tem um CHEAT para consertar isso, � bem simples.
Com o jogo rodando, aperte CONTROL+C, ir� aparecer uma tela, "CHEATS", ative a
seguinte op��o [Subscreen Delay Fix], depois aperte X da tela dos cheats, e volte a jogar :)

APLIQUEI PATCH, MAS AGORA O JOGO NAO APARECE TEXTO NENHUM
R. Voc� deve ter aplicado o Patch em rom errada, o ips tem que ser aplicado na
seguinte rom: Legend of Zelda, The - Ocarina of Time (U) (V1.0) [!].rom

N�O CONSIGO PEGAR O UPGRADE DE NOZ DEPOIS DE VIRAR ADULTO.
R. Isso � bug na vers�o 1.0 da rom, infelizmente n�o sei como consertar isso,
j� que n�o foi um problema feito por mim, ent�o eu recomendo pegar esse upgrade
antes de ficar adulto.

Maiores informa��es sobre ZELDA 64 OCARINA OF TIME: http://www.zelda.com.br

Tamb�m pe�o ajuda na revis�o do jogo, quem estiver querendo me ajudar nisso, basta
jogar o jogo at� o fim, e me mandar FOTOS dos erros, qualquer tipo de erro, at�
mesmo erros gramaticais.
				/---------------------\
				|	Fserve	      |
				|  [Tradu-Roms 2008]  | 
				|www.traduroms.cjb.net|
				\---------------------/
